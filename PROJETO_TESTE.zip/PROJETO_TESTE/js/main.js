// Introdução ao JS
// 1.1 - Variáveis
var novaVariavel;
let minhaVariavel = "Olá Mundo";

// 1.2 - Tipos de Dados
// 1.2.1 - Números
let minhaVariavel = 30;

// 1.2.2 - String
let meuNome = "Bonde do Tigrão";
let alunoNovo = "Batista";
let alunoTurista = "Catatau n°22";

// 1.2.3 - Boolean
let souLindo = true;
let souCharmoso = true;
let souChato = false;

// 1.2.4 - Nulo
let valorNulo = null;

// 1.2.5 - Indefinido
let valorIndefinido;

// 1.2.6 - Objeto
let minhaDataNascimento = new (1980,12,1);

// 1.3 - Operadores
let soma = 5 + 3;
let diferenca = 26 - 2;
let produto = 5 * 3;



// 1.4 - Funções
// 1.5 - Objetos
// 1.6 - Arrays
// 1.7 - Condicionais
// 1.8 - Loops
// 1.9 - Funções construtoras e objetos
// 1.10 - Funções de array